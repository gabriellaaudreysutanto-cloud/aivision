import streamlit as st
import os
import pandas as pd
from html import escape
from utils.api_handler import analyze_display_api, get_image_file
from components.header import render_header 


OWN_PRODUCT_HINTS = (
    "owner",
    "owned",
    "company",
    "customer",
    "otsuka",
    "pocari",
    "ion water",
    "soyjoy",
    "or beng",
    "fibe mini",
    "adem sari",
)


def classify_facing_type(label: str, item_type=None) -> str:
    if item_type:
        normalized_type = str(item_type).strip().lower()
        if normalized_type in {"owner", "owned", "company", "customer"}:
            return "owner"
        if normalized_type in {"competitor", "other", "detected"}:
            return normalized_type

    normalized_label = str(label or "").strip().lower()
    if any(token in normalized_label for token in OWN_PRODUCT_HINTS):
        return "owner"
    return "detected"


def format_bbox(bbox) -> str:
    if not isinstance(bbox, (list, tuple)) or len(bbox) < 4:
        return "-"
    return ", ".join(str(round(float(value), 1)) for value in bbox[:4])


def normalize_product_facing_rows(inner: dict) -> pd.DataFrame:
    if not isinstance(inner, dict):
        return pd.DataFrame()

    pf = inner.get("product_facing") or inner.get("productFacing")
    rows = []

    if isinstance(pf, dict) and pf:
        for facing_no, items in pf.items():
            if not isinstance(items, list) or not items:
                continue

            item = items[0]
            if not isinstance(item, dict):
                continue

            coord = item.get("coordinate", {})
            price = item.get("price", {})
            label = item.get("name") or item.get("label") or item.get("product_name") or "-"
            item_type = classify_facing_type(label, item.get("type"))

            rows.append({
                "Facing No": facing_no,
                "Product ID": item.get("product_id", "-"),
                "Product Name": label,
                "Type": item_type,
                "Confidence": item.get("confidence", "-"),
                "Regular Price": price.get("regular_price", "-") if isinstance(price, dict) else "-",
                "Promo Price": price.get("promo_price", "-") if isinstance(price, dict) else "-",
                "X": coord.get("x", "-") if isinstance(coord, dict) else "-",
                "Y": coord.get("y", "-") if isinstance(coord, dict) else "-",
                "BBox": format_bbox(item.get("bbox")),
            })

    detections = inner.get("detections") or inner.get("detected_products") or []
    if not rows and isinstance(detections, list) and detections:
        for index, item in enumerate(detections, start=1):
            if not isinstance(item, dict):
                continue

            label = item.get("label") or item.get("name") or item.get("product_name") or "-"
            item_type = classify_facing_type(label, item.get("type"))
            bbox = item.get("bbox") or item.get("xyxy")

            rows.append({
                "Facing No": index,
                "Product ID": item.get("product_id", "-"),
                "Product Name": label,
                "Type": item_type,
                "Confidence": item.get("confidence", "-"),
                "Regular Price": "-",
                "Promo Price": "-",
                "X": round(float(bbox[0]), 1) if isinstance(bbox, (list, tuple)) and len(bbox) >= 1 else "-",
                "Y": round(float(bbox[1]), 1) if isinstance(bbox, (list, tuple)) and len(bbox) >= 2 else "-",
                "BBox": format_bbox(bbox),
            })

    return pd.DataFrame(rows)


def render_facing_metric(label: str, value, color="#111827"):
    st.markdown(
        f"""
        <div class="pf-metric">
            <div class="pf-metric-label">{escape(label)}</div>
            <div class="pf-metric-value" style="color:{color};">{escape(str(value))}</div>
        </div>
        """,
        unsafe_allow_html=True,
    )


def merge_result_payload(old: dict, new: dict) -> dict:
    if not isinstance(old, dict):
        old = {}
    if not isinstance(new, dict):
        return old

    merged = {**old, **new}
    old_inner = old.get("result")
    new_inner = new.get("result")
    if isinstance(old_inner, dict) and isinstance(new_inner, dict):
        merged["result"] = {**old_inner, **new_inner}
    return merged

def render_result_page():

    # ===== Custom CSS =====
    st.markdown("""
        <style>
        .section-title {
            color: #1565C0;
            font-size: 20px;
            font-weight: 700;
            margin-bottom: 16px;
            padding-bottom: 8px;
            border-bottom: 2px solid #1565C0;
        }
        .image-container {
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
            margin-bottom: 20px;
        }
        .badge {
            display: inline-block;
            padding: 6px 12px;
            border-radius: 20px;
            font-size: 14px;
            font-weight: 600;
            margin: 4px;
        }
        .badge-success {
            background-color: #4caf50;
            color: white;
        }
        .badge-warning {
            background-color: #ff9800;
            color: white;
        }
        .pf-summary {
            display: grid;
            grid-template-columns: repeat(3, minmax(0, 1fr));
            gap: 12px;
            margin: 12px 0 20px 0;
        }
        .pf-metric {
            background: #ffffff;
            border: 1px solid #e5e7eb;
            border-radius: 10px;
            padding: 14px 12px;
            min-height: 84px;
            box-shadow: 0 8px 22px rgba(15, 23, 42, 0.06);
        }
        .pf-metric-label {
            color: #6b7280;
            font-size: 10px;
            font-weight: 800;
            text-transform: uppercase;
            margin-bottom: 8px;
        }
        .pf-metric-value {
            color: #111827;
            font-size: 26px;
            font-weight: 850;
            line-height: 1;
        }
        .pf-product-card {
            border: 1px solid #e5e7eb;
            border-radius: 10px;
            padding: 12px;
            background: #ffffff;
            margin-bottom: 10px;
            box-shadow: 0 8px 18px rgba(15, 23, 42, 0.05);
        }
        .pf-product-head {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 10px;
            margin-bottom: 6px;
        }
        .pf-product-name {
            color: #111827;
            font-weight: 800;
            font-size: 14px;
            line-height: 1.25;
        }
        .pf-tag {
            display: inline-flex;
            align-items: center;
            border-radius: 999px;
            padding: 4px 9px;
            background: #eef2ff;
            color: #3730a3;
            font-size: 11px;
            font-weight: 800;
            white-space: nowrap;
        }
        .pf-meta {
            color: #6b7280;
            font-size: 12px;
            display: flex;
            flex-wrap: wrap;
            gap: 8px 12px;
        }
        .pf-price-button-note {
            color: #6b7280;
            font-size: 12px;
            margin: 8px 0 8px 0;
        }
        @media (max-width: 900px) {
            .pf-summary {
                grid-template-columns: 1fr;
            }
        }
        </style>
    """, unsafe_allow_html=True)

    # ===== Header =====
    render_header("Analysis Result")

    col1, col2 = st.columns([1.2, 1], gap="large")

    # =======================
    # LEFT SIDE: IMAGE OUTPUT
    # =======================
    with col1:
        st.markdown("<div class='section-title'>Detection Output</div>", unsafe_allow_html=True)

        image_path = st.session_state.get("output_path")

        # Jika API ada output path → tampilkan hasil detection
        if image_path and os.path.exists(image_path):
            st.markdown("<div class='image-container'>", unsafe_allow_html=True)
            st.image(image_path, use_container_width=True)
            st.markdown("</div>", unsafe_allow_html=True)

        else:
            # ========= NEW FEATURE =========
            # Jika belum ada output image → user bisa upload gambar
            uploaded_img = st.file_uploader(
                "Upload an image",
                type=["jpg", "jpeg", "png"],
                label_visibility="collapsed",
            )

            if uploaded_img:
                st.session_state["manual_uploaded_image"] = uploaded_img

            if "manual_uploaded_image" in st.session_state:
                st.markdown("<div class='image-container'>", unsafe_allow_html=True)
                st.image(st.session_state["manual_uploaded_image"], use_container_width=True)
                st.markdown("</div>", unsafe_allow_html=True)
            else:
                st.error("No output image available")

    # =====================
    # RAW RESULT JSON LOAD
    # =====================
    raw_result = st.session_state.get("result", {}) or {}
    inner = raw_result.get("result", raw_result)

    # =====================
    # RIGHT SIDE: TABS
    # =====================
    with col2:

        tabs = st.tabs([
            "Overview",
            "Product Facing",
            "Share of Space",
            "Planogram",
            "Raw Data"
        ])

        # ===================================
        # TAB 1 — OVERVIEW
        # ===================================
        with tabs[0]:
            st.markdown("<div class='section-title'>Overview</div>", unsafe_allow_html=True)

            status = raw_result.get("status", "-")
            request_id = raw_result.get("request_id", "-")
            api_time = raw_result.get("api_time", "-")
            app_id = raw_result.get("app_id", "-")

            badge_class = "badge-success" if status == "success" else "badge-warning"
            st.markdown(
                f"<span class='badge {badge_class}'>{status.upper()}</span>",
                unsafe_allow_html=True
            )

            st.write("#### Request ID")
            st.code(request_id)

            st.write("#### API Response Time")
            st.write(api_time)

            st.write("#### App ID")
            st.code(app_id)

        # ===================================
        # TAB 2 — PRODUCT FACING + PRICE TAG
        # ===================================
        with tabs[1]:
            st.markdown("<div class='section-title'>Product Facing</div>", unsafe_allow_html=True)

            df_pf = normalize_product_facing_rows(inner)

            if df_pf.empty:
                st.info("No product facing data available")
            else:
                # =============================
                # SUMMARY METRICS
                # =============================
                total_facing = len(df_pf)
                owner_facing = len(df_pf[df_pf["Type"].astype(str).str.lower() == "owner"])
                ots_percentage = round((owner_facing / total_facing) * 100, 2) if total_facing else 0

                metric_cols = st.columns(3)
                with metric_cols[0]:
                    render_facing_metric("Total Facing", total_facing)
                with metric_cols[1]:
                    render_facing_metric("Company Facing", owner_facing)
                with metric_cols[2]:
                    render_facing_metric("Company %", f"{ots_percentage}%", "#4f46e5")

                # =============================
                # PRICE TAG ACTION
                # =============================
                st.markdown("""
                    <style>
                    div[data-testid="stButton"] > button[kind="secondary"] {
                        background: linear-gradient(135deg, #2563eb 0%, #4f46e5 100%);
                        color: white;
                        font-weight: 600;
                        border: none;
                        padding: 12px 24px;
                        border-radius: 8px;
                        box-shadow: 0 4px 12px rgba(102, 126, 234, 0.4);
                        transition: all 0.3s ease;
                    }
                    div[data-testid="stButton"] > button[kind="secondary"]:hover {
                        box-shadow: 0 6px 16px rgba(79, 70, 229, 0.35);
                        transform: translateY(-2px);
                    }
                    </style>
                """, unsafe_allow_html=True)
                st.markdown(
                    "<div class='pf-price-button-note'>Fetch price tags after detection if the model response has no price data yet.</div>",
                    unsafe_allow_html=True,
                )

                if st.button("Get Price Tag", use_container_width=True, key="fetch_price_tag"):

                    with st.spinner("Fetching price tag data..."):
                        saved = st.session_state.get("_last_inputs")
                        if not saved:
                            st.error("Missing input data.")
                            st.stop()

                        saved["pricetag"] = True
                        new_result = analyze_display_api(**saved)
                        request_id = saved["request_id"]
                        img_bytes = get_image_file(request_id, type="output")

                        new_out_path = f"output/{request_id}_output.jpg"
                        if isinstance(img_bytes, bytes):
                            with open(new_out_path, "wb") as f:
                                f.write(img_bytes)

                        old = st.session_state.get("result", {})
                        merged = merge_result_payload(old, new_result)
                        st.session_state.result = merged
                        st.session_state.output_path = new_out_path

                        st.success("Price tag data fetched.")
                        st.rerun()

                # =============================
                # FINAL TABLE
                # =============================
                st.markdown("### Product Facing Detail")
                # preview_rows = df_pf.head(6).to_dict("records")
                # for row in preview_rows:
                #     confidence = row.get("Confidence", "-")
                #     if isinstance(confidence, float):
                #         confidence = f"{confidence:.2%}"
                #     st.markdown(
                #         f"""
                #         <div class="pf-product-card">
                #             <div class="pf-product-head">
                #                 <div class="pf-product-name">#{escape(str(row.get("Facing No", "-")))} {escape(str(row.get("Product Name", "-")))}</div>
                #                 <span class="pf-tag">{escape(str(row.get("Type", "-")).title())}</span>
                #             </div>
                #             <div class="pf-meta">
                #                 <span>ID: {escape(str(row.get("Product ID", "-")))}</span>
                #                 <span>Confidence: {escape(str(confidence))}</span>
                #                 <span>Position: {escape(str(row.get("BBox", "-")))}</span>
                #             </div>
                #         </div>
                #         """,
                #         unsafe_allow_html=True,
                #     )

                # if len(df_pf) > len(preview_rows):
                #     st.caption(f"Showing {len(preview_rows)} preview cards. Full detection list is in the table below.")

                st.dataframe(
                    df_pf[
                        [
                            "Facing No",
                            "Product ID",
                            "Product Name",
                            "Type",
                            "Confidence",
                            "Regular Price",
                            "Promo Price",
                            "X",
                            "Y",
                            "BBox",
                        ]
                    ],
                    use_container_width=True,
                    hide_index=True,
                )

        # ===================================
        # TAB 3 — SHARE OF SPACE
        # ===================================
        with tabs[2]:
            st.markdown("<div class='section-title'>Share of Space</div>", unsafe_allow_html=True)

            sos = inner.get("share_of_space") or inner.get("shareOfSpace")

            if not sos:
                st.info("No share of space data available")
            else:
                all_cat = sos.get("all_category", {})

                score = all_cat.get("score", "-")
                cust_qty = all_cat.get("customer_qty", 0)
                comp_qty = all_cat.get("competitor_qty", 0)

                st.markdown(f"""
                    <div style='background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                                padding:20px; border-radius:10px; color:white; margin-bottom:16px;'>
                        <div style='font-size:14px; opacity:0.8;'>Share of Space Score</div>
                        <div style='font-size:32px; font-weight:700;'>{score}</div>
                    </div>
                """, unsafe_allow_html=True)

                c1, c2 = st.columns(2)
                c1.metric("Customer Qty", cust_qty)
                c2.metric("Competitor Qty", comp_qty)

                rows = []
                for cat, data in sos.items():
                    if cat == "all_category":
                        continue

                    rows.append({
                        "Category": cat,
                        "Customer Qty": data.get("customer_qty"),
                        "Competitor Qty": data.get("competitor_qty"),
                        "Score": data.get("score")
                    })

                if rows:
                    df_sos = pd.DataFrame(rows)
                    st.markdown("### Category Breakdown")
                    st.dataframe(df_sos, use_container_width=True, hide_index=True)

        # ===================================
        # TAB 4 — PLANOGRAM
        # ===================================
        with tabs[3]:
            st.markdown("<div class='section-title'>Planogram Compliance</div>", unsafe_allow_html=True)

            plan = inner.get("planogram") or inner.get("planogram_compliance")

            if not plan:
                st.info("No planogram data available")
            else:
                code = plan.get("planogram_code", "-")
                score = plan.get("score", "-")
                non = plan.get("not-compliance", {})

                # Card untuk Planogram Code
                st.markdown(f"""
                    <div style='background: linear-gradient(135deg, #5e72e4 0%, #825ee4 100%);
                                padding: 20px; border-radius: 12px; margin-bottom: 16px;
                                box-shadow: 0 4px 12px rgba(94, 114, 228, 0.25);'>
                        <div style='color: white; font-size: 13px; opacity: 0.9; 
                                    text-transform: uppercase; letter-spacing: 1px; margin-bottom: 8px;'>
                            Planogram Code
                        </div>
                        <div style='color: white; font-size: 28px; font-weight: 700;'>
                            {code}
                        </div>
                    </div>
                """, unsafe_allow_html=True)

                # Metrics dalam cards
                col_score, col_non = st.columns(2)
                
                with col_score:
                    st.markdown(f"""
                        <div style='background: linear-gradient(135deg, #11cdef 0%, #1171ef 100%);
                                    padding: 20px; border-radius: 12px; text-align: center;
                                    box-shadow: 0 4px 12px rgba(17, 205, 239, 0.25);'>
                            <div style='color: white; font-size: 12px; opacity: 0.9; 
                                        text-transform: uppercase; letter-spacing: 1px; margin-bottom: 8px;'>
                                Compliance Score
                            </div>
                            <div style='color: white; font-size: 36px; font-weight: 700;'>
                                {score}
                            </div>
                        </div>
                    """, unsafe_allow_html=True)
                
                with col_non:
                    status_gradient = "linear-gradient(135deg, #f5365c 0%, #f56036 100%)" if len(non) > 0 else "linear-gradient(135deg, #2dce89 0%, #2dcecc 100%)"
                    st.markdown(f"""
                        <div style='background: {status_gradient};
                                    padding: 20px; border-radius: 12px; text-align: center;
                                    box-shadow: 0 4px 12px rgba(45, 206, 137, 0.25);'>
                            <div style='color: white; font-size: 12px; opacity: 0.9; 
                                        text-transform: uppercase; letter-spacing: 1px; margin-bottom: 8px;'>
                                Non-Compliance
                            </div>
                            <div style='color: white; font-size: 36px; font-weight: 700;'>
                                {len(non)}
                            </div>
                        </div>
                    """, unsafe_allow_html=True)

                # Tabel Non-Compliance
                rows = [{"Position": pos, "Product ID": pid} for pos, pid in non.items()]

                if rows:
                    st.markdown("<div style='margin-top: 24px;'></div>", unsafe_allow_html=True)
                    st.markdown("### Non-Compliance Details")
                    df_plan = pd.DataFrame(rows)
                    st.dataframe(df_plan, use_container_width=True, hide_index=True)
                else:
                    st.markdown("<div style='margin-top: 16px;'></div>", unsafe_allow_html=True)
                    st.success("✓ All items are compliant with planogram")

        # ===================================
        # TAB 5 — RAW DATA
        # ===================================
        with tabs[4]:
            st.markdown("<div class='section-title'>Raw JSON Result</div>", unsafe_allow_html=True)
            st.json(raw_result or {})
