import streamlit as st
import os
import uuid
import json

from utils.api_handler import analyze_display_api, get_image_file
from utils.db import fetch_all, execute_query
from components.header import render_header


# ===================== PREMIUM CSS =====================
def inject_css():
    st.markdown("""
    <style>

    .main > div {
        max-width: 900px !important;
        margin-left: auto !important;
        margin-right: auto !important;
        padding-top: 10px !important;
    }

    .section-title {
        font-size: 20px;
        font-weight: 700;
        color: #0b5bff;
        margin: 25px 0 14px 0;
    }

    .input-data-title {
        margin-top: 1px !important;
    }

    div[data-testid="stFileUploader"] > section {
        border: 2px dashed #c7d6ff !important;
        background: #f5f8ff !important;
        border-radius: 14px !important;
        padding: 28px !important;
    }

    div[data-testid="stFileUploader"] {
        margin-bottom: 28px !important;
    }

    label {
        font-weight: 600 !important;
        color: #1f2937 !important;
        margin-bottom: 4px !important;
    }

    .execute-btn > button {
        height: 32px !important;
        font-size: 13px !important;
        font-weight: 600 !important;
        border-radius: 8px !important;
        background: linear-gradient(135deg, #032aa7 0%, #0b5bff 100%) !important;
        border: none !important;
        color: white !important;
        padding-top: 4px !important;
        padding-bottom: 4px !important;
    }

    .execute-btn > button:hover {
        background: linear-gradient(135deg, #0434a4 0%, #0d63ff 100%) !important;
    }

    </style>
    """, unsafe_allow_html=True)


# ===================== FETCH APP LIST FROM DB =====================
@st.cache_data(show_spinner=False, ttl=60)
def fetch_app_list():
    try:
        rows = fetch_all("""
            SELECT app_id
            FROM master_apps
            WHERE deleted_at IS NULL
            ORDER BY id
        """)
        return [row["app_id"] for row in rows]
    except Exception as e:
        print("App list fetch error:", e)
        return []


# ===================== FETCH PLANOGRAM LIST FROM DB =====================
@st.cache_data(show_spinner=False, ttl=60)
def fetch_planogram_list(app_id: str):
    if not app_id or app_id == "Choose an option":
        return []

    try:
        rows = fetch_all("""
            SELECT planogram_id, name
            FROM master_planograms
            WHERE deleted_at IS NULL
              AND app_id = %s
            ORDER BY id
        """, (app_id,))
        return [f"{row['planogram_id']} — {row['name']}" for row in rows]
    except Exception as e:
        print("Planogram fetch error:", e)
        return []


# ===================== MAIN PAGE =====================
def render_home_page():
    inject_css()
    render_header("AI Vision Dashboard")

    if "request_id" not in st.session_state:
        st.session_state.request_id = str(uuid.uuid4())

    request_id = st.session_state.request_id

    # ===================== UPLOAD FILE =====================
    st.markdown("<div class='section-title'>Upload File</div>", unsafe_allow_html=True)

    file = st.file_uploader("Upload Image", type=["jpg", "jpeg", "png"])

    if file:
        upload_folder = "uploads"
        os.makedirs(upload_folder, exist_ok=True)

        filename = f"{uuid.uuid4()}_{file.name}"
        save_path = os.path.join(upload_folder, filename)

        with open(save_path, "wb") as f:
            f.write(file.getbuffer())

        st.session_state.uploaded_path = save_path
        st.session_state.uploaded_filename = filename
        st.session_state.original_filename = file.name
        st.session_state.uploaded_mime_type = file.type
        st.session_state.uploaded_size = file.size

        st.success("File uploaded successfully.")

    # ===================== INPUT DATA =====================
    st.markdown("<div class='section-title input-data-title'>Input Data</div>", unsafe_allow_html=True)
    st.markdown("<div class='input-card'>", unsafe_allow_html=True)

    app_list = fetch_app_list()

    selected_app = st.selectbox(
        "App ID *",
        ["Choose an option"] + app_list,
        key="selected_app",
    )

    if selected_app == "Choose an option":
        planogram_options = []
    else:
        planogram_options = fetch_planogram_list(selected_app)

    if len(planogram_options) == 0:
        planogram_raw = st.selectbox(
            "Planogram ID",
            ["None"],
            key="planogram_id_select"
        )
        planogram_id = None
    else:
        options_with_none = ["None"] + planogram_options

        planogram_raw = st.selectbox(
            "Planogram ID",
            options_with_none,
            key="planogram_id_select"
        )

        if planogram_raw == "None":
            planogram_id = None
        else:
            planogram_id = planogram_raw.split(" — ")[0]

    pricetag = st.selectbox("Pricetag", [False, True])

    st.markdown("</div>", unsafe_allow_html=True)

    # ===================== EXECUTE BUTTON =====================
    st.markdown("<div class='execute-btn'>", unsafe_allow_html=True)

    if st.button("Execute", use_container_width=True):
        if "uploaded_path" not in st.session_state:
            st.error("Please upload an image first.")
            return

        if selected_app == "Choose an option":
            st.error("Please select an App ID first.")
            return

        img_path = st.session_state.uploaded_path
        image_id = f"IMG_{request_id}"
        inference_id = f"INF_{request_id}"

        # 1. Simpan upload metadata ke DB
        try:
            execute_query("""
                INSERT INTO uploaded_images
                (image_id, app_id, original_filename, stored_filename, file_path, mime_type, file_size, uploaded_by, uploaded_at, status)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, NOW(), %s)
                ON CONFLICT (image_id) DO NOTHING
            """, (
                image_id,
                selected_app,
                st.session_state.get("original_filename", os.path.basename(img_path)),
                st.session_state.get("uploaded_filename", os.path.basename(img_path)),
                img_path,
                st.session_state.get("uploaded_mime_type", "image/jpeg"),
                st.session_state.get("uploaded_size", 0),
                "streamlit_user",
                "UPLOADED"
            ))
        except Exception as e:
            st.error(f"Failed saving uploaded image metadata: {e}")
            return

        # 2. Jalankan AI API
        try:
            result = analyze_display_api(
                image_path=img_path,
                request_id=request_id,
                app_id=selected_app,
                planogram_id=planogram_id,
                pricetag=pricetag,
            )
        except Exception as e:
            st.error(f"Failed executing AI analysis: {e}")
            return

        st.session_state._last_inputs = {
            "image_path": img_path,
            "request_id": request_id,
            "app_id": selected_app,
            "planogram_id": planogram_id,
            "pricetag": pricetag,
        }

        # 3. Simpan inference run ke DB
        try:
            execute_query("""
                INSERT INTO inference_runs
                (inference_id, image_id, model_id, app_id, inference_type, status, started_at, finished_at, processing_time_ms, request_payload, response_payload, created_at)
                VALUES (%s, %s, %s, %s, %s, %s, NOW(), NOW(), %s, %s::jsonb, %s::jsonb, NOW())
                ON CONFLICT (inference_id) DO NOTHING
            """, (
                inference_id,
                image_id,
                "MODEL001",
                selected_app,
                "PRODUCT_DETECTION",
                "SUCCESS" if isinstance(result, dict) and result.get("status") != "failed" else "FAILED",
                0,
                json.dumps({
                    "request_id": request_id,
                    "app_id": selected_app,
                    "planogram_id": planogram_id,
                    "pricetag": pricetag,
                    "image_path": img_path,
                }),
                json.dumps(result if result is not None else {})
            ))
        except Exception as e:
            st.error(f"Failed saving inference run: {e}")
            return

        # 4. Save output image
        try:
            output_image = get_image_file(request_id, "output")
            if isinstance(output_image, bytes):
                os.makedirs("output", exist_ok=True)
                out_path = f"output/{request_id}_output.jpg"
                if not os.path.exists(out_path):
                    with open(out_path, "wb") as f:
                        f.write(output_image)
                st.session_state.output_path = out_path
        except Exception as e:
            print("Output image save error:", e)

        # 5. Simpan result ke session agar result_page tetap jalan
        st.session_state.result = result
        st.session_state.inference_id = inference_id
        st.session_state.image_id = image_id
        st.session_state.menu_selected = "Result"
        st.rerun()

    st.markdown("</div>", unsafe_allow_html=True)
