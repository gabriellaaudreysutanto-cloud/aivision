import streamlit as st
import pandas as pd
import math
import os
import re
import hashlib
from difflib import SequenceMatcher
from html import escape
from PIL import Image
from components.header import render_header
from utils.db import fetch_all, execute_query

try:
    from ultralytics import YOLO
except Exception:
    YOLO = None

css_path = "/home/kai-01/AI-Vision/Dashboard/assets/styles_table.css"
MODEL_PATH = os.getenv("YOLO_MODEL_PATH", "models/best.pt")
PLANOGRAM_UPLOAD_DIR = os.path.join("uploads", "planogram_checks")
PLANOGRAM_OUTPUT_DIR = os.path.join("output", "planogram_checks")

PRODUCT_NAME_ALIASES = {
    "pocari": "pocari sweat",
    "pocari sweat": "pocari sweat",
    "ion": "ion water",
    "ion water": "ion water",
    "ion water 350": "ion water",
    "ion water 330": "ion water",
    "soy joy": "soyjoy",
    "soyjoy": "soyjoy",
    "or beng": "or beng",
    "fibe": "fibe mini",
    "fibe mini": "fibe mini",
    "adem sari": "adem sari",
    "you c1000": "youc1000",
    "youc1000": "youc1000",
    "hydro coco": "hydrococo",
    "hydrococo": "hydrococo",
    "hemaviton": "hemaviton",
    "isoplus": "isoplus",
}


@st.cache_data(show_spinner=False, ttl=60)
def load_planogram_list() -> pd.DataFrame:
    rows = fetch_all(
        """
        SELECT
            mp.planogram_id,
            mp.app_id,
            mp.name AS planogram_name,
            mp.content,
            mp.created_at,
            mp.updated_at
        FROM master_planograms mp
        WHERE mp.deleted_at IS NULL
        ORDER BY mp.updated_at DESC
        """
    )
    return pd.DataFrame(rows)


@st.cache_data(show_spinner=False, ttl=60)
def load_planogram_items(planogram_id: str) -> pd.DataFrame:
    rows = fetch_all(
        """
        SELECT
            mpi.planogram_id,
            mpi.shelf_row,
            mpi.shelf_column,
            mpi.expected_count,
            mpi.product_id,
            mp.product_name,
            mp.short_name,
            mp.product_type,
            mb.brand_name,
            mb.brand_group
        FROM master_planogram_items mpi
        LEFT JOIN master_products mp
            ON mpi.product_id = mp.product_id
        LEFT JOIN master_brands mb
            ON mp.brand_id = mb.brand_id
        WHERE mpi.planogram_id = %s
        ORDER BY mpi.shelf_row, mpi.shelf_column
        """,
        (planogram_id,)
    )
    return pd.DataFrame(rows)


def apply_planogram_styles():
    st.markdown(
        """
        <style>
            .plano-workspace {
                background: #ffffff;
                border: 1px solid #e5e7eb;
                border-radius: 18px;
                padding: 22px;
                box-shadow: 0 16px 40px rgba(15, 23, 42, 0.08);
                margin-top: 16px;
            }
            .plano-panel-title {
                color: #111827;
                font-size: 20px;
                font-weight: 800;
                margin: 0 0 8px 0;
            }
            .plano-muted {
                color: #6b7280;
                font-size: 13px;
                margin-bottom: 12px;
            }
            .plano-empty-photo {
                min-height: 360px;
                border: 2px dashed #cbd5e1;
                border-radius: 14px;
                background: #f8fafc;
                display: flex;
                align-items: center;
                justify-content: center;
                color: #64748b;
                font-weight: 700;
                text-align: center;
                padding: 24px;
            }
            .plano-toolbar {
                display: flex;
                align-items: center;
                justify-content: space-between;
                gap: 14px;
                margin: 4px 0 14px 0;
                flex-wrap: wrap;
            }
            .plano-legend {
                display: flex;
                gap: 16px;
                align-items: center;
                flex-wrap: wrap;
                color: #374151;
                font-size: 13px;
                font-weight: 650;
            }
            .plano-legend-item {
                display: inline-flex;
                align-items: center;
                gap: 7px;
            }
            .plano-swatch {
                width: 18px;
                height: 18px;
                border-radius: 5px;
                border: 1px solid #cbd5e1;
                display: inline-block;
            }
            .plano-grid-wrap {
                overflow-x: auto;
                padding: 8px 2px 4px 2px;
            }
            .plano-grid {
                display: grid;
                gap: 9px;
                min-width: 620px;
            }
            .plano-cell {
                min-height: 70px;
                border: 1px solid #d9e2ef;
                border-radius: 8px;
                background: #f8fafc;
                color: #64748b;
                display: flex;
                align-items: center;
                justify-content: center;
                text-align: center;
                padding: 8px;
                font-size: 12px;
                line-height: 1.25;
                font-weight: 650;
                box-sizing: border-box;
            }
            .plano-cell.own {
                background: #2563eb;
                border-color: #1d4ed8;
                color: #ffffff;
                box-shadow: 0 8px 20px rgba(37, 99, 235, 0.22);
            }
            .plano-cell.competitor {
                background: #fff7ed;
                border-color: #fb923c;
                color: #c2410c;
            }
            .plano-cell.other {
                background: #eef2ff;
                border-color: #a5b4fc;
                color: #3730a3;
            }
            .plano-cell.empty {
                background: #f9fafb;
                color: #9ca3af;
            }
            .distribution-card {
                background: #ffffff;
                border: 1px solid #e5e7eb;
                border-radius: 18px;
                padding: 26px 28px 24px 28px;
                box-shadow: 0 16px 40px rgba(15, 23, 42, 0.08);
                margin-top: 22px;
            }
            .distribution-title {
                display: flex;
                align-items: center;
                gap: 12px;
                color: #111827;
                font-size: 22px;
                font-weight: 850;
                margin-bottom: 24px;
            }
            .distribution-icon {
                width: 22px;
                height: 22px;
                border: 2px solid #2563eb;
                border-radius: 50%;
                position: relative;
                box-sizing: border-box;
            }
            .distribution-icon:after {
                content: "";
                position: absolute;
                width: 9px;
                height: 9px;
                right: -2px;
                top: -2px;
                background: #ffffff;
                border-left: 2px solid #2563eb;
                border-bottom: 2px solid #2563eb;
            }
            .distribution-row {
                margin: 18px 0 26px 0;
            }
            .distribution-head {
                display: flex;
                justify-content: space-between;
                align-items: baseline;
                gap: 16px;
                color: #374151;
                font-size: 16px;
                font-weight: 800;
                margin-bottom: 10px;
            }
            .distribution-count {
                color: #6b7280;
                font-size: 14px;
                font-weight: 650;
                margin-top: 8px;
            }
            .distribution-percent {
                font-size: 16px;
                font-weight: 850;
            }
            .distribution-track {
                width: 100%;
                height: 12px;
                border-radius: 999px;
                background: #e5e7eb;
                overflow: hidden;
            }
            .distribution-fill {
                height: 100%;
                border-radius: 999px;
            }
            .compliance-card {
                background: #ffffff;
                border: 1px solid #e5e7eb;
                border-radius: 18px;
                padding: 24px 28px;
                box-shadow: 0 16px 40px rgba(15, 23, 42, 0.08);
                margin-top: 22px;
            }
            .compliance-title {
                color: #111827;
                font-size: 22px;
                font-weight: 850;
                margin-bottom: 18px;
            }
            .compliance-metrics {
                display: grid;
                grid-template-columns: repeat(4, minmax(0, 1fr));
                gap: 12px;
                margin-bottom: 18px;
            }
            .compliance-metric {
                border: 1px solid #e5e7eb;
                border-radius: 10px;
                padding: 14px;
                background: #f8fafc;
            }
            .compliance-metric-label {
                color: #64748b;
                font-size: 11px;
                font-weight: 800;
                text-transform: uppercase;
                margin-bottom: 8px;
            }
            .compliance-metric-value {
                color: #111827;
                font-size: 24px;
                font-weight: 850;
                line-height: 1;
            }
            .compliance-message {
                border-radius: 10px;
                padding: 12px 14px;
                margin: 8px 0;
                font-size: 14px;
                font-weight: 650;
                line-height: 1.45;
            }
            .compliance-message.match {
                background: #ecfdf5;
                color: #047857;
                border: 1px solid #a7f3d0;
            }
            .compliance-message.mismatch {
                background: #fff7ed;
                color: #c2410c;
                border: 1px solid #fed7aa;
            }
            .compliance-message.missing {
                background: #fef2f2;
                color: #b91c1c;
                border: 1px solid #fecaca;
            }
            .compliance-message.unexpected {
                background: #eff6ff;
                color: #1d4ed8;
                border: 1px solid #bfdbfe;
            }
            @media (max-width: 900px) {
                .compliance-metrics {
                    grid-template-columns: repeat(2, minmax(0, 1fr));
                }
            }
        </style>
        """,
        unsafe_allow_html=True,
    )


def classify_planogram_item(row: pd.Series) -> str:
    product_id = row.get("product_id")
    product_name = row.get("product_name")
    if pd.isna(product_id) or not str(product_id).strip() or pd.isna(product_name):
        return "empty"

    values = " ".join(
        str(row.get(field, "") or "").lower()
        for field in ["product_type", "brand_name", "brand_group"]
    )

    if any(token in values for token in ["competitor", "pesaing"]):
        return "competitor"
    if any(token in values for token in ["own", "owner", "owned", "otsuka", "principal"]):
        return "own"
    return "other"


def build_planogram_cells(df: pd.DataFrame, rows: int, cols: int):
    cells = []
    for r in range(1, rows + 1):
        for c in range(1, cols + 1):
            cell = df[(df["shelf_row"] == r) & (df["shelf_column"] == c)]
            if cell.empty:
                cells.append(
                    {
                        "row": r,
                        "col": c,
                        "label": f"{r}.{c}",
                        "category": "empty",
                    }
                )
                continue

            item = cell.iloc[0]
            label = f"{r}.{c}"
            for field in ["short_name", "product_name"]:
                value = item.get(field)
                if not pd.isna(value) and str(value).strip():
                    label = str(value).strip()
                    break

            expected_count = item.get("expected_count")
            if not pd.isna(expected_count) and int(expected_count or 0) > 1:
                label = f"{label} ({int(expected_count)})"

            cells.append(
                {
                    "row": r,
                    "col": c,
                    "label": str(label),
                    "category": classify_planogram_item(item),
                }
            )
    return cells


@st.cache_resource(show_spinner=False)
def load_yolo_model():
    if YOLO is None:
        raise RuntimeError("Ultralytics YOLO is not installed or could not be imported.")
    if not os.path.exists(MODEL_PATH):
        raise FileNotFoundError(f"YOLO model file was not found: {MODEL_PATH}")
    return YOLO(MODEL_PATH)


def normalize_product_name(value) -> str:
    if value is None or pd.isna(value):
        return ""

    text = str(value).lower().strip()
    text = re.sub(r"[^a-z0-9]+", " ", text)
    text = re.sub(r"\s+", " ", text).strip()
    prefix_words = {
        "kompetitor",
        "competitor",
        "customer",
        "owner",
        "own",
        "product",
        "produk",
        "brand",
    }
    text = " ".join(token for token in text.split() if token not in prefix_words)

    if text in PRODUCT_NAME_ALIASES:
        return PRODUCT_NAME_ALIASES[text]

    for alias, canonical in PRODUCT_NAME_ALIASES.items():
        if alias in text:
            return canonical

    stop_words = {"ml", "ltr", "liter", "botol", "bottle", "pet", "pack", "pcs"}
    tokens = [token for token in text.split() if token not in stop_words and not token.isdigit()]
    return " ".join(tokens)


def names_match(expected_name: str, detected_name: str) -> bool:
    expected = normalize_product_name(expected_name)
    detected = normalize_product_name(detected_name)

    if not expected or not detected:
        return False
    if expected == detected:
        return True
    if expected in detected or detected in expected:
        return True

    return SequenceMatcher(None, expected, detected).ratio() >= 0.72


def expected_planogram_positions(df: pd.DataFrame):
    expected = {}
    for _, row in df.iterrows():
        shelf_row = row.get("shelf_row")
        shelf_col = row.get("shelf_column")
        product_name = row.get("short_name")
        if pd.isna(product_name) or not str(product_name).strip():
            product_name = row.get("product_name")

        if pd.isna(shelf_row) or pd.isna(shelf_col) or pd.isna(product_name):
            continue

        position = (int(shelf_row), int(shelf_col))
        expected[position] = {
            "row": int(shelf_row),
            "col": int(shelf_col),
            "product_id": row.get("product_id"),
            "product_name": str(product_name).strip(),
            "canonical_name": normalize_product_name(product_name),
            "expected_count": int(row.get("expected_count") or 1),
            "match_values": [
                row.get("product_id"),
                row.get("short_name"),
                row.get("product_name"),
            ],
        }
    return expected


def detection_matches_expected(expected, detection) -> bool:
    detected_name = detection.get("class_name")
    return any(
        names_match(match_value, detected_name)
        for match_value in expected.get("match_values", [])
        if match_value is not None and not pd.isna(match_value)
    )


def save_uploaded_planogram_image(uploaded_image, planogram_id: str, image_hash: str) -> str:
    os.makedirs(PLANOGRAM_UPLOAD_DIR, exist_ok=True)
    extension = os.path.splitext(uploaded_image.name or "")[1].lower()
    if extension not in {".jpg", ".jpeg", ".png"}:
        extension = ".jpg"

    safe_planogram_id = re.sub(r"[^a-zA-Z0-9_-]+", "_", str(planogram_id))
    image_path = os.path.join(
        PLANOGRAM_UPLOAD_DIR,
        f"{safe_planogram_id}_{image_hash[:12]}{extension}",
    )

    with open(image_path, "wb") as image_file:
        image_file.write(uploaded_image.getvalue())

    return image_path


def run_yolo_detection(image_path: str, image_hash: str):
    model = load_yolo_model()
    results = model.predict(source=image_path, conf=0.1, imgsz=640, save=False)
    if not results:
        return [], None

    result = results[0]
    detections = []

    with Image.open(image_path) as image:
        image_width, image_height = image.size

    if result.boxes is not None:
        for box in result.boxes:
            class_id = int(box.cls[0].item())
            confidence = float(box.conf[0].item())
            bbox = [round(float(value), 2) for value in box.xyxy[0].tolist()]
            label = str(model.names.get(class_id, class_id))

            detections.append(
                {
                    "class_id": class_id,
                    "class_name": label,
                    "canonical_name": normalize_product_name(label),
                    "confidence": round(confidence, 4),
                    "bbox": bbox,
                    "center_x": (bbox[0] + bbox[2]) / 2,
                    "center_y": (bbox[1] + bbox[3]) / 2,
                    "image_width": image_width,
                    "image_height": image_height,
                }
            )

    annotated_path = None
    try:
        os.makedirs(PLANOGRAM_OUTPUT_DIR, exist_ok=True)
        annotated_path = os.path.join(PLANOGRAM_OUTPUT_DIR, f"{image_hash[:12]}_detected.jpg")
        plotted = result.plot()
        Image.fromarray(plotted[..., ::-1]).save(annotated_path)
    except Exception:
        annotated_path = None

    return detections, annotated_path


def map_detections_to_shelf_positions(detections, rows: int, cols: int):
    if not detections:
        return []

    sorted_detections = sorted(detections, key=lambda item: item.get("center_y", 0))
    box_heights = [
        abs(item["bbox"][3] - item["bbox"][1])
        for item in sorted_detections
        if isinstance(item.get("bbox"), list) and len(item["bbox"]) >= 4
    ]
    median_box_height = sorted(box_heights)[len(box_heights) // 2] if box_heights else 0
    image_height = sorted_detections[0].get("image_height") or 1
    row_threshold = max(median_box_height * 0.75, image_height / max(rows * 3, 1))

    row_groups = []
    for detection in sorted_detections:
        center_y = float(detection.get("center_y", 0))
        if not row_groups:
            row_groups.append([detection])
            continue

        last_group = row_groups[-1]
        last_center = sum(float(item.get("center_y", 0)) for item in last_group) / len(last_group)
        if abs(center_y - last_center) <= row_threshold:
            last_group.append(detection)
        else:
            row_groups.append([detection])

    while len(row_groups) > rows:
        closest_index = min(
            range(len(row_groups) - 1),
            key=lambda index: abs(
                (
                    sum(float(item.get("center_y", 0)) for item in row_groups[index]) / len(row_groups[index])
                )
                - (
                    sum(float(item.get("center_y", 0)) for item in row_groups[index + 1]) / len(row_groups[index + 1])
                )
            ),
        )
        row_groups[closest_index].extend(row_groups.pop(closest_index + 1))

    mapped = []
    for row_index, row_group in enumerate(row_groups, start=1):
        row_group = sorted(row_group, key=lambda item: item.get("center_x", 0))
        left = min(float(item.get("center_x", 0)) for item in row_group)
        right = max(float(item.get("center_x", 0)) for item in row_group)
        width = max(right - left, 1)

        for group_index, detection in enumerate(row_group):
            if len(row_group) >= cols:
                shelf_col = min(cols, max(1, int(group_index * cols / len(row_group)) + 1))
            else:
                normalized_x = (float(detection.get("center_x", 0)) - left) / width
                shelf_col = min(cols, max(1, int(round(normalized_x * (cols - 1))) + 1))

            mapped.append(
                {
                    **detection,
                    "shelf_row": min(rows, row_index),
                    "shelf_col": shelf_col,
                    "position": (min(rows, row_index), shelf_col),
                }
            )

    mapped.sort(key=lambda item: (item["shelf_row"], item["shelf_col"], -item["confidence"]))
    return mapped


def best_detection_for_position(mapped_detections, position):
    candidates = [item for item in mapped_detections if item["position"] == position]
    if not candidates:
        return None
    return max(candidates, key=lambda item: item["confidence"])


def compare_planogram_to_detections(expected_positions, mapped_detections):
    messages = []
    matched = 0
    misplaced = 0
    mismatched = 0
    missing = 0
    used_detection_ids = set()

    for position, expected in sorted(expected_positions.items()):
        position_detections = [
            item for item in mapped_detections
            if item["position"] == position and id(item) not in used_detection_ids
        ]
        actual = max(position_detections, key=lambda item: item["confidence"]) if position_detections else None
        row_label = f"Row {position[0]}, Column {position[1]}"
        expected_count = max(1, int(expected.get("expected_count") or 1))

        matching_detections = [
            item for item in position_detections
            if detection_matches_expected(expected, item)
        ]

        nearby_matching_detections = []
        if len(matching_detections) < expected_count:
            nearby_matching_detections = [
                item for item in mapped_detections
                if id(item) not in used_detection_ids
                and item["shelf_row"] == position[0]
                and abs(item["shelf_col"] - position[1]) <= 1
                and item["position"] != position
                and detection_matches_expected(expected, item)
            ]

        same_row_matching_detections = []
        if len(matching_detections) + len(nearby_matching_detections) < expected_count:
            same_row_matching_detections = [
                item for item in mapped_detections
                if id(item) not in used_detection_ids
                and item["shelf_row"] == position[0]
                and item["position"] != position
                and item not in nearby_matching_detections
                and detection_matches_expected(expected, item)
            ]

        all_matching_detections = (
            matching_detections
            + nearby_matching_detections
            + same_row_matching_detections
        )

        if len(all_matching_detections) >= expected_count:
            selected_matches = sorted(
                all_matching_detections,
                key=lambda item: (
                    0 if item["position"] == position else 1,
                    abs(item["shelf_col"] - position[1]),
                    -item["confidence"],
                ),
            )[:expected_count]
            used_detection_ids.update(id(item) for item in selected_matches)
            best_match = max(selected_matches, key=lambda item: item["confidence"])
            if best_match["position"] == position:
                matched += 1
                message = (
                    f"{row_label}: matched {expected['product_name']} "
                    f"with {len(selected_matches)} detected facing(s). "
                    f"Best confidence: {best_match['confidence']:.0%}."
                )
                status = "match"
            elif abs(best_match["shelf_col"] - position[1]) <= 1:
                matched += 1
                message = (
                    f"{row_label}: matched {expected['product_name']} nearby "
                    f"at Column {best_match['shelf_col']} "
                    f"({best_match['confidence']:.0%} confidence)."
                )
                status = "match"
            else:
                misplaced += 1
                message = (
                    f"{row_label}: expected {expected['product_name']} and detected it on the same shelf "
                    f"at Column {best_match['shelf_col']} "
                    f"({best_match['confidence']:.0%} confidence)."
                )
                status = "misplaced"

            messages.append(
                {
                    "status": status,
                    "message": message,
                }
            )
            continue

        if all_matching_detections:
            mismatched += 1
            used_detection_ids.update(id(item) for item in all_matching_detections)
            messages.append(
                {
                    "status": "mismatch",
                    "message": (
                        f"{row_label}: expected {expected_count} facing(s) of {expected['product_name']}, "
                        f"but detected {len(all_matching_detections)} matching facing(s)."
                    ),
                }
            )
        elif actual is None:
            missing += 1
            messages.append(
                {
                    "status": "missing",
                    "message": f"{row_label}: expected {expected['product_name']}, but no product was detected in this shelf position.",
                }
            )
        else:
            mismatched += 1
            used_detection_ids.add(id(actual))
            messages.append(
                {
                    "status": "mismatch",
                    "message": (
                        f"{row_label}: expected {expected['product_name']}, "
                        f"but detected {actual['class_name']} ({actual['confidence']:.0%} confidence)."
                    ),
                }
            )

    unexpected_positions = []
    for detection in mapped_detections:
        if id(detection) not in used_detection_ids and detection["position"] not in expected_positions:
            unexpected_positions.append(detection)

    for detection in unexpected_positions:
        messages.append(
            {
                "status": "unexpected",
                "message": (
                    f"Row {detection['shelf_row']}, Column {detection['shelf_col']}: "
                    f"detected unexpected product {detection['class_name']} ({detection['confidence']:.0%} confidence)."
                ),
            }
        )

    total_expected = len(expected_positions)
    score = round(((matched + misplaced) / total_expected) * 100, 2) if total_expected else 0

    return {
        "score": score,
        "matched": matched,
        "misplaced": misplaced,
        "mismatched": mismatched,
        "missing": missing,
        "unexpected": len(unexpected_positions),
        "total_expected": total_expected,
        "total_detected": len(mapped_detections),
        "messages": messages,
    }


def render_compliance_summary(comparison):
    with st.container(border=True):
        st.markdown("### Planogram Compliance Check")
        metric_cols = st.columns(5)
        metric_cols[0].metric("Score", f"{comparison['score']}%")
        metric_cols[1].metric("Matched", comparison["matched"])
        metric_cols[2].metric("Same Shelf", comparison["misplaced"])
        metric_cols[3].metric("Mismatched", comparison["mismatched"])
        metric_cols[4].metric("Missing", comparison["missing"])
        st.caption(
            f"Compared {comparison['total_detected']} detected products against "
            f"{comparison['total_expected']} expected shelf positions. "
            f"Unexpected detections: {comparison['unexpected']}."
        )

        for item in comparison["messages"]:
            status = item["status"]
            message = item["message"]
            if status == "match":
                st.success(message)
            elif status == "misplaced":
                st.info(message)
            elif status == "missing":
                st.error(message)
            elif status == "unexpected":
                st.info(message)
            else:
                st.warning(message)


def render_distribution_summary(cells):
    occupied_cells = [cell for cell in cells if cell["category"] != "empty"]
    total = len(occupied_cells)
    groups = [
        ("Otsuka Products", "own", "#2563eb"),
        ("Competitor Products", "competitor", "#d83b01"),
        ("Other Brands", "other", "#4b5563"),
    ]

    # with st.container(border=True):
    #     st.markdown("### Shelf Product Distribution")
    #     for label, key, color in groups:
    #         count = len([cell for cell in occupied_cells if cell["category"] == key])
    #         percent = round((count / total) * 100) if total else 0
    #         top_left, top_right = st.columns([4, 1])
    #         top_left.markdown(f"**{label}**")
    #         top_right.markdown(
    #             f"<span style='color:{color}; font-weight:800;'>{percent}%</span>",
    #             unsafe_allow_html=True,
    #         )
    #         st.progress(percent / 100 if percent else 0)
    #         st.caption(f"{count} products")


def render_planogram_grid(planogram_id: str):
    df = load_planogram_items(planogram_id)

    if df.empty:
        st.warning(f"Tidak ada layout item untuk planogram {planogram_id}")
        return

    max_row = int(df["shelf_row"].max())
    max_col = int(df["shelf_column"].max())
    cells = build_planogram_cells(df, max_row, max_col)
    filled_count = len([cell for cell in cells if cell["category"] != "empty"])
    comparison = None

    left, right = st.columns([0.95, 1.45], gap="large")

    with left:
        st.markdown('<p class="plano-panel-title">Planogram Photo</p>', unsafe_allow_html=True)
        uploaded_image = st.file_uploader(
            "Upload shelf image",
            type=["jpg", "jpeg", "png"],
            label_visibility="collapsed",
            key=f"planogram_image_{planogram_id}",
        )
        if uploaded_image:
            image_bytes = uploaded_image.getvalue()
            image_hash = hashlib.sha256(image_bytes).hexdigest()
            inference_key = f"planogram_compliance_{planogram_id}_{image_hash}"

            if inference_key not in st.session_state:
                with st.spinner("Running shelf detection and checking compliance..."):
                    try:
                        image_path = save_uploaded_planogram_image(
                            uploaded_image,
                            planogram_id,
                            image_hash,
                        )
                        detections, annotated_path = run_yolo_detection(image_path, image_hash)
                        mapped_detections = map_detections_to_shelf_positions(
                            detections,
                            max_row,
                            max_col,
                        )
                        expected_positions = expected_planogram_positions(df)
                        comparison = compare_planogram_to_detections(
                            expected_positions,
                            mapped_detections,
                        )
                        st.session_state[inference_key] = {
                            "image_path": image_path,
                            "annotated_path": annotated_path,
                            "detections": detections,
                            "mapped_detections": mapped_detections,
                            "comparison": comparison,
                        }
                    except Exception as e:
                        st.session_state[inference_key] = {
                            "error": str(e),
                            "comparison": None,
                        }

            inference_result = st.session_state.get(inference_key, {})
            comparison = inference_result.get("comparison")
            if inference_result.get("error"):
                st.error(f"Failed running shelf compliance check: {inference_result['error']}")
                st.image(uploaded_image, use_container_width=True)
            elif inference_result.get("annotated_path") and os.path.exists(inference_result["annotated_path"]):
                st.image(inference_result["annotated_path"], use_container_width=True)
            else:
                st.image(uploaded_image, use_container_width=True)
        else:
            st.markdown(
                """
                <div class="plano-empty-photo">
                    Drag and drop the shelf photo here<br>
                    JPG, JPEG, or PNG
                </div>
                """,
                unsafe_allow_html=True,
            )

    with right:
        st.markdown(
            f"""
            <p class="plano-panel-title">Planogram Grid</p>
            <div class="plano-toolbar">
                <div class="plano-muted">{escape(planogram_id)} - {max_row} rows - {max_col} columns - {filled_count} filled cells</div>
                <div class="plano-legend">
                    <span class="plano-legend-item"><span class="plano-swatch" style="background:#2563eb;"></span> Terisi</span>
                    <span class="plano-legend-item"><span class="plano-swatch" style="background:#f9fafb;"></span> Kosong</span>
                    <span class="plano-legend-item"><span class="plano-swatch" style="background:#fff7ed;border-color:#fb923c;"></span> Kompetitor</span>
                </div>
            </div>
            """,
            unsafe_allow_html=True,
        )

        grid_html = "".join(
            f"""
            <div class="plano-cell {escape(cell['category'])}" title="Row {cell['row']}, Column {cell['col']}">
                {escape(cell['label'])}
            </div>
            """
            for cell in cells
        )
        st.markdown(
            f"""
            <div class="plano-grid-wrap">
                <div class="plano-grid" style="grid-template-columns: repeat({max_col}, minmax(96px, 1fr));">
                    {grid_html}
                </div>
            </div>
            """,
            unsafe_allow_html=True,
        )

    render_distribution_summary(cells)
    if comparison:
        render_compliance_summary(comparison)

def split_frame(input_df: pd.DataFrame, rows: int):
    return [
        input_df.loc[i: i + rows - 1, :].reset_index(drop=True)
        for i in range(0, len(input_df), rows)
    ]


@st.cache_data(show_spinner=False, ttl=60)
def fetch_apps():
    return fetch_all("""
        SELECT app_id, app_name
        FROM master_apps
        WHERE deleted_at IS NULL
        ORDER BY app_name
    """)


def read_planogram():
    render_header("Planogram List")
    apply_planogram_styles()

    try:
        dataset = load_planogram_list()
    except Exception as e:
        st.error(f"❌ Failed to load planogram data from database: {e}")
        return

    if "show_add_planogram_form" not in st.session_state:
        st.session_state.show_add_planogram_form = False

    if "show_add_layout_form" not in st.session_state:
        st.session_state.show_add_layout_form = False

    if "show_delete_planogram_form" not in st.session_state:
        st.session_state.show_delete_planogram_form = False

    st.markdown(
        """
        <style>
            .add-btn {
                display: inline-flex;
                align-items: center;
                justify-content: center;
                gap: 10px;
                padding: 8px 26px;
                background: linear-gradient(135deg, #2563EB, #3B82F6);
                color: white !important;
                font-weight: 700;
                border-radius: 40px;
                text-decoration: none !important;
                font-size: 14px;
                box-shadow: 0px 4px 10px rgba(37, 99, 235, 0.25);
                transition: all 0.25s ease-in-out;
                white-space: nowrap;
            }
            .add-btn:hover {
                transform: translateY(-2px);
                background: linear-gradient(135deg, #1D4ED8, #60A5FA);
            }
            .add-btn-icon {
                background: white;
                width: 22px;
                height: 22px;
                border-radius: 50%;
                display: flex;
                align-items: center;
                justify-content: center;
                color: #2563EB;
                font-size: 14px;
                font-weight: 900;
            }
        </style>
        """,
        unsafe_allow_html=True,
        
    )
    

    search = st.text_input("Search", placeholder="Search planogram name, app_id, or planogram_id...")

    q = (search or "").strip().lower()
    if q:
        dataset = dataset[
            dataset.astype(str)
            .apply(lambda col: col.str.lower().str.contains(q, na=False))
            .any(axis=1)
        ]

    sort_row = st.columns([3, 1])

    with sort_row[0]:
        sort = st.radio("Sort Data", ["No", "Yes"], horizontal=True)

    with sort_row[1]:
        btn_col1, btn_col2, btn_col3 = st.columns(3)
        if btn_col1.button("Add Planogram", use_container_width=True):
            st.session_state.show_add_planogram_form = True
            st.session_state.show_add_layout_form = False
            st.session_state.show_delete_planogram_form = False
        if btn_col2.button("Add Layout Detail", use_container_width=True):
            st.session_state.show_add_layout_form = True
            st.session_state.show_add_planogram_form = False
            st.session_state.show_delete_planogram_form = False
        if btn_col3.button("Delete Planogram", use_container_width=True):
            st.session_state.show_delete_planogram_form = True
            st.session_state.show_add_planogram_form = False
            st.session_state.show_add_layout_form = False

    if st.session_state.show_add_planogram_form:
        st.markdown("### Add Planogram Form")
        try:
            apps = fetch_apps()
        except Exception as e:
            st.error(f"Failed loading application options: {e}")
            return

        app_labels = ["- Select App -"] + [
            f"{row['app_id']} - {row['app_name']}" for row in apps
        ]

        with st.form("add_planogram_form", clear_on_submit=True):
            selected_app = st.selectbox("Application", app_labels)
            planogram_id = st.text_input("Planogram ID", placeholder="PL001")
            planogram_name = st.text_input("Planogram Name", placeholder="Shelf layout A")
            content = st.text_area("Content", placeholder='{"rows": []}', height=140)
            form_col1, form_col2 = st.columns(2)
            save_planogram = form_col1.form_submit_button("Save Planogram", use_container_width=True)
            cancel_planogram = form_col2.form_submit_button("Cancel", use_container_width=True)

            if save_planogram:
                if selected_app == "- Select App -" or not planogram_id.strip() or not planogram_name.strip():
                    st.warning("Application, Planogram ID, and Planogram Name are required.")
                else:
                    app_id = selected_app.split(" - ", 1)[0]
                    try:
                        execute_query(
                            """
                            INSERT INTO master_planograms
                            (planogram_id, app_id, name, content, created_at, updated_at)
                            VALUES (%s, %s, %s, %s, NOW(), NOW())
                            """,
                            (
                                planogram_id.strip(),
                                app_id,
                                planogram_name.strip(),
                                content.strip() or None,
                            ),
                        )
                        st.cache_data.clear()
                        st.session_state.show_add_planogram_form = False
                        st.success("Planogram created successfully.")
                        st.rerun()
                    except Exception as e:
                        st.error(f"Failed creating planogram: {e}")

            if cancel_planogram:
                st.session_state.show_add_planogram_form = False
                st.rerun()

    if st.session_state.show_add_layout_form:
        st.markdown("### Add Layout Detail Form")
        if dataset.empty:
            st.info("No planogram available. Create a planogram first.")
        else:
            planogram_labels = [
                f"{row['planogram_id']} - {row['planogram_name']}" for _, row in dataset.iterrows()
            ]
            with st.form("add_layout_form", clear_on_submit=True):
                selected_planogram = st.selectbox("Planogram", planogram_labels)
                layout_content = st.text_area("Layout Detail", placeholder='{"layout": []}', height=180)
                form_col1, form_col2 = st.columns(2)
                save_layout = form_col1.form_submit_button("Save Layout Detail", use_container_width=True)
                cancel_layout = form_col2.form_submit_button("Cancel", use_container_width=True)

                if save_layout:
                    if not layout_content.strip():
                        st.warning("Layout detail content is required.")
                    else:
                        current_planogram_id = selected_planogram.split(" - ", 1)[0]
                        try:
                            execute_query(
                                """
                                UPDATE master_planograms
                                SET content = %s,
                                    updated_at = NOW()
                                WHERE planogram_id = %s
                                  AND deleted_at IS NULL
                                """,
                                (
                                    layout_content.strip(),
                                    current_planogram_id,
                                ),
                            )
                            st.cache_data.clear()
                            st.session_state.show_add_layout_form = False
                            st.success("Layout detail saved successfully.")
                            st.rerun()
                        except Exception as e:
                            st.error(f"Failed saving layout detail: {e}")

            if cancel_layout:
                st.session_state.show_add_layout_form = False
                st.rerun()

    if st.session_state.show_delete_planogram_form:
        st.markdown("### Delete Planogram")
        if dataset.empty:
            st.info("No planogram data available to delete.")
        else:
            delete_options = [
                f"{row['planogram_id']} - {row['planogram_name']}" for _, row in dataset.iterrows()
            ]
            selected_planogram = st.selectbox("Select Planogram to Delete", delete_options, key="delete_planogram_select")

            with st.form("delete_planogram_form"):
                confirm_delete = st.checkbox("I understand this planogram will be hidden from master data lists.")
                delete_col1, delete_col2 = st.columns(2)
                delete_submit = delete_col1.form_submit_button("Delete Planogram", use_container_width=True)
                delete_cancel = delete_col2.form_submit_button("Cancel", use_container_width=True)

                if delete_submit:
                    if not confirm_delete:
                        st.warning("Please confirm before deleting.")
                    else:
                        planogram_id_to_delete = selected_planogram.split(" - ", 1)[0]
                        try:
                            execute_query(
                                """
                                UPDATE master_planograms
                                SET deleted_at = NOW(),
                                    updated_at = NOW()
                                WHERE planogram_id = %s
                                  AND deleted_at IS NULL
                                """,
                                (planogram_id_to_delete,),
                            )
                            st.cache_data.clear()
                            st.session_state.show_delete_planogram_form = False
                            st.success("Planogram deleted successfully.")
                            st.rerun()
                        except Exception as e:
                            st.error(f"Failed deleting planogram: {e}")

                if delete_cancel:
                    st.session_state.show_delete_planogram_form = False
                    st.rerun()

    if sort == "Yes":
        sort_col = st.selectbox("Sort By", dataset.columns.tolist())
        sort_dir = st.radio("Direction", ["⬆️", "⬇️"], horizontal=True)
        dataset = dataset.sort_values(
            by=sort_col,
            ascending=(sort_dir == "⬆️"),
            ignore_index=True
        )

    pagination = st.container()
    menu = st.columns((4, 1, 1))

    if len(dataset) == 0:
        st.info("No matching planogram found.")
        return

    with menu[2]:
        batch_size = st.selectbox("Page Size", [25, 50, 100], index=0)

    with menu[1]:
        total_pages = max(1, math.ceil(len(dataset) / batch_size))
        current_page = st.number_input("Page", 1, total_pages, step=1)

    with menu[0]:
        st.markdown(
            f"Page **{current_page}** of **{total_pages}** — showing **{len(dataset)}** planograms"
        )

        pages = split_frame(dataset, batch_size)
    idx = min(int(current_page - 1), len(pages) - 1)

    pagination.dataframe(pages[idx], use_container_width=True)

    # Preview grid planogram
    if not dataset.empty:
        selected_planogram_id = st.selectbox(
            "Preview Grid Planogram",
            dataset["planogram_id"].dropna().astype(str).unique().tolist()
        )
        render_planogram_grid(selected_planogram_id)
